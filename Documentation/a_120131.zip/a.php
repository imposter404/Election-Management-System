<?php

session_start();
$_SESSION['g']=1400;

echo $_SESSION['g'];


?>