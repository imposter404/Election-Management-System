<?php


session_start();
// $_SESSION['g']=100;

echo $_SESSION['g'];


?>