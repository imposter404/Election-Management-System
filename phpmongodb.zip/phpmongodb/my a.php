<?php

echo "hi";
// Ensure the MongoDB extension is loaded
if (!extension_loaded('mongodb')) {
    die('MongoDB extension is not loaded');
}
require "vendor/autoload.php";
// Create a MongoDB client
$client = new MongoDB\Client("mongodb://localhost:27017"); // Replace with your connection string

// // Select a database
// $database = $client->selectDatabase('your_database_name');

// // Select a collection
// $collection = $database->selectCollection('your_collection_name');

// // Example: Insert a document
// $insertResult = $collection->insertOne([
//     'name' => 'John Doe',
//     'email' => 'john@example.com',
// ]);

// echo "Inserted document with ID: " . $insertResult->getInsertedId() . "\n";

// // Example: Find a document
// $document = $collection->findOne(['name' => 'John Doe']);
// print_r($document);
?>